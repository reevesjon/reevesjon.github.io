-- Create database if not exists
CREATE DATABASE IF NOT EXISTS 4050_test;

USE 4050_test;

-- Drop tables if they exist (for testing purposes)
DROP TABLE IF EXISTS Notifications;
DROP TABLE IF EXISTS ActivityLog;
DROP TABLE IF EXISTS Documents;
DROP TABLE IF EXISTS Comments;
DROP TABLE IF EXISTS Tasks;
DROP TABLE IF EXISTS Teams;
DROP TABLE IF EXISTS Projects;
DROP TABLE IF EXISTS Users;
DROP TABLE IF EXISTS Roles;

-- Create tables
CREATE TABLE Roles (
    role_id INT PRIMARY KEY AUTO_INCREMENT,
    role_name VARCHAR(50) NOT NULL,
    description TEXT
);

CREATE TABLE Users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    role_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES Roles(role_id)
);

CREATE TABLE Projects (
    project_id INT PRIMARY KEY AUTO_INCREMENT,
    project_name VARCHAR(100) NOT NULL,
    description TEXT,
    start_date DATE,
    end_date DATE,
    status VARCHAR(20),
    owner_id INT,
    percent_complete DECIMAL(5, 2),
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES Users(user_id),
    FOREIGN KEY (owner_id) REFERENCES Users(user_id)
);

CREATE TABLE Teams (
    team_id INT PRIMARY KEY AUTO_INCREMENT,
    team_name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE Tasks (
    task_id INT PRIMARY KEY AUTO_INCREMENT,
    task_name VARCHAR(100) NOT NULL,
    description TEXT,
    owner_id INT,
    `rank` INT,
    priority VARCHAR(10),
    start_date DATE,
    end_date DATE,
    due_date DATE,
    status VARCHAR(20),
    percent_complete DECIMAL(5, 2),
    estimated_days INT,
    actual_days INT,
    next_task_id INT,
    project_id INT,
    assigned_to INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES Projects(project_id),
    FOREIGN KEY (assigned_to) REFERENCES Users(user_id),
    FOREIGN KEY (owner_id) REFERENCES Users(user_id),
    FOREIGN KEY (next_task_id) REFERENCES Tasks(task_id)
);

CREATE TABLE Comments (
    comment_id INT PRIMARY KEY AUTO_INCREMENT,
    comment_text TEXT NOT NULL,
    task_id INT,
    user_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES Tasks(task_id),
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

CREATE TABLE Documents (
    document_id INT PRIMARY KEY AUTO_INCREMENT,
    document_name VARCHAR(100) NOT NULL,
    document_path VARCHAR(255) NOT NULL,
    project_id INT,
    task_id INT NULL,
    uploaded_by INT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES Projects(project_id),
    FOREIGN KEY (task_id) REFERENCES Tasks(task_id),
    FOREIGN KEY (uploaded_by) REFERENCES Users(user_id)
);

CREATE TABLE ActivityLog (
    activity_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    activity_type VARCHAR(50),
    details TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

CREATE TABLE Notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    message TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

-- Insert test data for Roles
INSERT INTO Roles (role_name, description) VALUES
('SysAdmin', 'System Administrator responsible for infrastructure'),
('Manager1', 'Manages a specific team or project'),
('Manager2', 'Manages another specific team or project'),
('User', 'Regular user with limited access');

-- Insert test data for Users
INSERT INTO Users (username, email, password, first_name, last_name, role_id) VALUES
('sysadmin1', 'sysadmin1@example.com', 'password123', 'Hank', 'SysAdmin', 1),
('sysadmin2', 'sysadmin2@example.com', 'password123', 'Sarah', 'SysAdmin', 1),
('manager1', 'manager1@example.com', 'password123', 'Frank', 'Manager1', 2),
('manager2', 'manager2@example.com', 'password123', 'Grace', 'Manager2', 3),
('user1', 'user1@example.com', 'password123', 'John', 'Doe', 4),
('user2', 'user2@example.com', 'password123', 'Jane', 'Smith', 4),
('user3', 'user3@example.com', 'password123', 'Bill', 'Williams', 4),
('user4', 'user4@example.com', 'password123', 'Mike', 'Johnson', 4),
('user5', 'user5@example.com', 'password123', 'Emily', 'Davis', 4),
('user6', 'user6@example.com', 'password123', 'Tom', 'Miller', 4),
('user7', 'user7@example.com', 'password123', 'Laura', 'Wilson', 4);

-- Insert test data for Projects
INSERT INTO Projects (project_name, description, start_date, end_date, status, owner_id, percent_complete, created_by) VALUES
('Infrastructure Overhaul', 'Upgrade company IT infrastructure', '2024-07-01', '2024-10-01', 'In Progress', 2, 75.0, 1),
('Mobile App Development', 'Develop a mobile application for e-commerce', '2024-10-01', '2025-03-01', 'Not Started', 2, 0.0, 1),
('Database Migration', 'Migrate legacy data to the new system', '2024-08-15', '2024-11-15', 'In Progress', 3, 50.0, 1),
('Website Redesign', 'Redesign the corporate website for better UX', '2024-07-15', '2024-10-30', 'In Progress', 2, 40.0, 3),
('ERP Implementation', 'Implement a new ERP system for the company', '2024-09-01', '2025-01-01', 'Not Started', 3, 0.0, 3),
('Cloud Migration', 'Migrate services to a cloud infrastructure', '2024-08-01', '2024-12-01', 'In Progress', 3, 60.0, 1),
('Cybersecurity Enhancement', 'Enhance company’s cybersecurity measures', '2024-07-01', '2024-12-01', 'In Progress', 3, 45.0, 1);

-- Insert test data for Teams
INSERT INTO Teams (team_name, description) VALUES
('Development Team', 'Handles all development tasks'),
('QA Team', 'Responsible for testing and quality assurance'),
('SysAdmin Team', 'Manages system infrastructure and network security'),
('Design Team', 'Handles UI/UX and graphic design tasks'),
('Operations Team', 'Responsible for daily operations and support'),
('Security Team', 'Handles security audits and measures');

-- Insert test data for Tasks
INSERT INTO Tasks (task_name, description, owner_id, `rank`, priority, start_date, end_date, due_date, status, percent_complete, estimated_days, actual_days, next_task_id, project_id, assigned_to) VALUES
('Network Upgrade', 'Upgrade network infrastructure for better performance', 1, 1, 'High', '2024-07-10', '2024-08-20', '2024-08-20', 'Completed', 100.0, 30, 25, NULL, 1, 1),
('Security Audit', 'Conduct a full security audit on the new infrastructure', 1, 2, 'Medium', '2024-09-01', '2024-09-30', '2024-09-30', 'In Progress', 50.0, 20, 10, NULL, 1, 1),
('Backend Development', 'Develop the backend API for the mobile app', 2, 3, 'High', '2024-10-01', '2024-11-01', '2024-11-01', 'Completed', 100.0, 20, 0, NULL, 2, 2),
('Frontend Development', 'Create the mobile app frontend', 2, 4, 'High', '2024-11-01', '2024-12-01', '2024-12-01', 'In Progress', 60.0, 20, 10, NULL, 2, 2),
('Database Design', 'Design the new database schema for data migration', 3, 5, 'High', '2024-08-20', '2024-09-15', '2024-09-15', 'Completed', 100.0, 15, 14, NULL, 3, 3),
('Data Migration', 'Migrate legacy data to the new schema', 3, 6, 'High', '2024-09-16', '2024-11-15', '2024-11-15', 'In Progress', 80.0, 30, 20, NULL, 3, 3),
('UI Design', 'Design the UI for the new website', 4, 7, 'Medium', '2024-07-20', '2024-08-20', '2024-08-20', 'Completed', 100.0, 20, 15, NULL, 4, 4),
('SEO Optimization', 'Optimize the website for search engines', 2, 8, 'Low', '2024-09-01', '2024-09-15', '2024-09-15', 'In Progress', 40.0, 10, 5, NULL, 4, 4),
('ERP System Configuration', 'Configure the new ERP system', 3, 9, 'High', '2024-09-15', '2024-10-15', '2024-10-15', 'Not Started', 0.0, 30, 0, NULL, 5, 3),
('Cloud Security Setup', 'Implement security measures for the cloud migration', 1, 10, 'High', '2024-08-05', '2024-09-30', '2024-09-30', 'In Progress', 70.0, 25, 15, NULL, 6, 1),
('Firewall Installation', 'Install and configure new firewalls', 1, 11, 'High', '2024-08-10', '2024-09-01', '2024-09-01', 'Completed', 100.0, 20, 18, NULL, 7, 1),
('Penetration Testing', 'Perform penetration testing on the new systems', 4, 12, 'Medium', '2024-09-15', '2024-10-30', '2024-10-30', 'Not Started', 0.0, 30, 0, NULL, 7, 4),
('Data Analytics', 'Analyze the data from the recent project', 2, 13, 'Medium', '2024-09-20', '2024-09-30', '2024-09-30', 'In Progress', 40.0, 15, 6, NULL, 3, 2),
('Mobile App Testing', 'Test the mobile application for bugs', 3, 14, 'High', '2024-10-01', '2024-10-20', '2024-10-20', 'In Progress', 20.0, 20, 4, NULL, 2, 3),
('API Documentation', 'Document the API endpoints for developers', 1, 15, 'Low', '2024-09-15', '2024-09-25', '2024-09-25', 'Completed', 100.0, 5, 5, NULL, 2, 1),
('Infrastructure Monitoring', 'Set up monitoring for network infrastructure', 5, 16, 'Medium', '2024-08-01', '2024-09-01', '2024-09-01', 'In Progress', 75.0, 15, 10, NULL, 1, 5),
('Backup Strategy Implementation', 'Implement a backup strategy for the database', 3, 17, 'High', '2024-08-20', '2024-09-30', '2024-09-30', 'In Progress', 50.0, 20, 10, NULL, 4, 3),
('User Training', 'Conduct training sessions for new software', 4, 18, 'Medium', '2024-09-01', '2024-09-20', '2024-09-20', 'Completed', 100.0, 10, 10, NULL, 6, 2),
('System Upgrade', 'Upgrade the operating system on all workstations', 3, 19, 'Medium', '2024-09-01', '2024-09-15', '2024-09-15', 'In Progress', 30.0, 15, 5, NULL, 5, 3),
('Cloud Migration', 'Migrate applications to the cloud environment', 2, 20, 'High', '2024-09-10', '2024-11-01', '2024-11-01', 'In Progress', 60.0, 40, 15, NULL, 6, 1),
('Legacy System Decommission', 'Decommission old legacy systems', 1, 21, 'High', '2024-09-15', '2024-10-30', '2024-10-30', 'Not Started', 0.0, 30, 0, NULL, 4, 2),
('Test1', 'TestDesc', 3, 22, 'High', '2024-09-15', '2024-10-30', '2024-10-30', 'Completed', 100.00, 30, 30, NULL, 1, 5),
('Test2', 'TestDesc', 3, 22, 'Normal', '2024-09-15', '2024-10-30', '2024-10-30', 'Completed', 100.00, 30, 30, NULL, 1, 6),
('Test3', 'TestDesc', 3, 22, 'Normal', '2024-09-15', '2024-10-30', '2024-10-30', 'Completed', 100.00, 30, 30, NULL, 1, 7),
('Test4', 'TestDesc', 3, 22, 'High', '2024-09-15', '2024-10-30', '2024-10-30', 'Completed', 100.00, 30, 30, NULL, 1, 7),
('Test5', 'TestDesc', 3, 22, 'Normal', '2024-09-15', '2024-10-30', '2024-10-30', 'Completed', 100.00, 30, 30, NULL, 1, 6),
('Test6', 'TestDesc', 3, 22, 'High', '2024-09-15', '2024-10-30', '2024-10-30', 'Completed', 100.00, 30, 30, NULL, 1, 5),
('Test7', 'TestDesc', 3, 22, 'High', '2024-09-15', '2024-10-30', '2024-10-30', 'Completed', 100.00, 30, 30, NULL, 1, 5),
('Test8', 'TestDesc', 3, 22, 'Normal', '2024-09-15', '2024-10-30', '2024-10-30', 'Completed', 100.00, 30, 30, NULL, 1, 6),
('Test9', 'TestDesc', 3, 22, 'Normal', '2024-09-15', '2024-10-30', '2024-10-30', 'Completed', 100.00, 30, 30, NULL, 1, 7),
('Test10', 'TestDesc', 3, 22, 'High', '2024-09-15', '2024-10-30', '2024-10-30', 'Completed', 100.00, 30, 30, NULL, 1, 7),
('Test11', 'TestDesc', 3, 22, 'Normal', '2024-09-15', '2024-10-30', '2024-10-30', 'Completed', 100.00, 30, 30, NULL, 1, 6),
('Test12', 'TestDesc', 3, 22, 'High', '2024-09-15', '2024-10-30', '2024-10-30', 'Completed', 100.00, 30, 30, NULL, 1, 5),
-- Additional tasks for each user
('Task A1', 'Description A1', 1, 22, 'Medium', '2024-09-01', '2024-09-10', '2024-09-10', 'In Progress', 20.0, 5, 2, NULL, 1, 1),
('Task A2', 'Description A2', 1, 23, 'Low', '2024-09-05', '2024-09-15', '2024-09-15', 'Completed', 100.0, 7, 7, NULL, 1, 1),
('Task B1', 'Description B1', 2, 24, 'High', '2024-09-01', '2024-09-20', '2024-09-20', 'Not Started', 0.0, 10, 0, NULL, 2, 2),
('Task B2', 'Description B2', 2, 25, 'Medium', '2024-09-10', '2024-09-25', '2024-09-25', 'In Progress', 50.0, 5, 3, NULL, 2, 2),
('Task C1', 'Description C1', 3, 26, 'High', '2024-09-15', '2024-09-30', '2024-09-30', 'In Progress', 25.0, 15, 5, NULL, 3, 3),
('Task C2', 'Description C2', 3, 27, 'Medium', '2024-09-20', '2024-10-05', '2024-10-05', 'Not Started', 0.0, 10, 0, NULL, 3, 3),
('Task D1', 'Description D1', 4, 28, 'Low', '2024-09-01', '2024-09-10', '2024-09-10', 'Completed', 100.0, 5, 5, NULL, 4, 4),
('Task D2', 'Description D2', 4, 29, 'Medium', '2024-09-05', '2024-09-15', '2024-09-15', 'In Progress', 50.0, 8, 4, NULL, 4, 4);
-- User 1 (User ID 5): High performance (completed high-priority tasks on time)
INSERT INTO Tasks (task_name, description, owner_id, `rank`, priority, start_date, end_date, due_date, status, percent_complete, estimated_days, actual_days, next_task_id, project_id, assigned_to) VALUES
('Network Upgrade', 'Upgrade network infrastructure', 5, 1, 'High', '2024-07-10', '2024-08-20', '2024-08-20', 'Completed', 100.0, 30, 25, NULL, 1, 5),
('Firewall Installation', 'Install firewalls', 5, 2, 'High', '2024-08-10', '2024-09-01', '2024-09-01', 'Completed', 100.0, 20, 18, NULL, 2, 5);

-- User 2 (User ID 6): Medium performance (partially completed high-priority tasks, on time)
INSERT INTO Tasks (task_name, description, owner_id, `rank`, priority, start_date, end_date, due_date, status, percent_complete, estimated_days, actual_days, next_task_id, project_id, assigned_to) VALUES
('Backend Development', 'Develop backend API', 6, 1, 'High', '2024-10-01', '2024-11-01', '2024-11-01', 'In Progress', 50.0, 30, 0, NULL, 1, 6),
('Frontend Development', 'Develop frontend UI', 6, 2, 'Medium', '2024-10-10', '2024-11-15', '2024-11-15', 'Completed', 100.0, 20, 19, NULL, 2, 6);

-- User 3 (User ID 7): Low performance (low completion rate, some overdue high-priority tasks)
INSERT INTO Tasks (task_name, description, owner_id, `rank`, priority, start_date, end_date, due_date, status, percent_complete, estimated_days, actual_days, next_task_id, project_id, assigned_to) VALUES
('Database Design', 'Design new schema', 7, 1, 'High', '2024-08-20', '2024-09-15', '2024-09-15', 'In Progress', 20.0, 15, 0, NULL, 1, 7),
('Data Migration', 'Migrate data', 7, 2, 'High', '2024-09-16', '2024-11-15', '2024-11-15', 'In Progress', 40.0, 30, 0, NULL, 2, 7);

-- User 4 (User ID 8): High performance (completed high-priority tasks slightly late)
INSERT INTO Tasks (task_name, description, owner_id, `rank`, priority, start_date, end_date, due_date, status, percent_complete, estimated_days, actual_days, next_task_id, project_id, assigned_to) VALUES
('UI Design', 'Design UI for website', 8, 1, 'High', '2024-07-20', '2024-08-25', '2024-08-20', 'Completed', 100.0, 20, 22, NULL, 1, 8),
('SEO Optimization', 'Optimize for SEO', 8, 2, 'Medium', '2024-09-01', '2024-09-10', '2024-09-15', 'Completed', 100.0, 10, 10, NULL, 2, 8);

-- User 5 (User ID 9): Medium-low performance (in-progress high-priority task, low priority completed)
INSERT INTO Tasks (task_name, description, owner_id, `rank`, priority, start_date, end_date, due_date, status, percent_complete, estimated_days, actual_days, next_task_id, project_id, assigned_to) VALUES
('Infrastructure Monitoring', 'Monitor infrastructure', 9, 1, 'High', '2024-08-01', '2024-09-15', '2024-09-01', 'In Progress', 50.0, 15, 0, NULL, 1, 9),
('Backup Strategy', 'Implement backup strategy', 9, 2, 'Low', '2024-08-15', '2024-09-01', '2024-09-01', 'Completed', 100.0, 20, 20, NULL, 2, 9);

-- User 6 (User ID 10): Low performance (in-progress, late, high-priority tasks)
INSERT INTO Tasks (task_name, description, owner_id, `rank`, priority, start_date, end_date, due_date, status, percent_complete, estimated_days, actual_days, next_task_id, project_id, assigned_to) VALUES
('Cloud Migration', 'Migrate to cloud', 10, 1, 'High', '2024-09-10', '2024-11-01', '2024-10-15', 'In Progress', 30.0, 40, 0, NULL, 1, 10),
('ERP System Setup', 'Configure ERP', 10, 2, 'Medium', '2024-09-15', '2024-10-10', '2024-10-05', 'Not Started', 0.0, 25, 0, NULL, 2, 10);

-- User 7 (User ID 11): Lowest performance (not started high-priority tasks)
INSERT INTO Tasks (task_name, description, owner_id, `rank`, priority, start_date, end_date, due_date, status, percent_complete, estimated_days, actual_days, next_task_id, project_id, assigned_to) VALUES
('Penetration Testing', 'Pen test systems', 11, 1, 'High', '2024-09-15', '2024-10-30', '2024-10-25', 'Not Started', 0.0, 20, 0, NULL, 1, 11),
('User Training', 'Train users on new software', 11, 2, 'Medium', '2024-10-01', '2024-10-20', '2024-10-20', 'In Progress', 25.0, 15, 5, NULL, 2, 11);



-- Insert test data for Comments
INSERT INTO Comments (comment_text, task_id, user_id) VALUES
('Initial network upgrade is complete and performing well.', 1, 1),
('Found some security gaps during the audit, will address them next.', 2, 1),
('Backend API structure is finalized, development is ready to start.', 3, 2),
('UI design is complete and awaiting review.', 7, 5),
('SEO optimization is yielding positive results so far.', 8, 2),
('Firewall installation was completed ahead of schedule.', 11, 1),
('Penetration testing is scheduled to begin next week.', 12, 4);

-- Insert test data for Documents
INSERT INTO Documents (document_name, document_path, project_id, task_id, uploaded_by) VALUES
('Network Diagram', '/documents/network_diagram.pdf', 1, 1, 1),
('Security Audit Report', '/documents/security_audit_report.pdf', 1, 2, 1),
('Backend API Documentation', '/documents/backend_api_docs.pdf', 2, 3, 2),
('UI Mockup', '/documents/ui_mockup.pdf', 5, 7, 5),
('Firewall Configuration Guide', '/documents/firewall_config_guide.pdf', 7, 11, 1);

-- Insert test data for ActivityLog
INSERT INTO ActivityLog (user_id, activity_type, details) VALUES
(1, 'Login', 'SysAdmin logged in successfully.'),
(2, 'Task Update', 'Updated Backend Development task progress.'),
(3, 'Project Status Update', 'Updated the status of the Database Migration project.'),
(4, 'Task Comment', 'Added comment to Penetration Testing task.'),
(5, 'Document Upload', 'Uploaded UI Mockup to Website Redesign project.');
